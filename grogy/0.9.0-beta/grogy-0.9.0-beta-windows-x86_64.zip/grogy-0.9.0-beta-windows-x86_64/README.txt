Grogy 0.9.0 Beta
Unzip this folder and run grogy.exe
