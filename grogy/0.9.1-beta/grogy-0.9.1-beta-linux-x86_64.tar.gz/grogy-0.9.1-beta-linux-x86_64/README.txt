Grogy 0.9.1 Beta
Unzip this folder and run ./grogy
