Grogy 0.9.2 Beta
Unzip this folder and run ./grogy
