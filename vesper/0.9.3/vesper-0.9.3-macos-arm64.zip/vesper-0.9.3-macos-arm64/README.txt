Vesper 0.9.3
Open vesper.app. The first time, Control-click it and choose Open.
If macOS says the app is damaged, run: xattr -dr com.apple.quarantine vesper.app
The library is saved in ~/Library/Application Support/vesper/vesper.
This build is for Apple Silicon and needs macOS 14.4. It is self-signed as TheWhiteWitchTM. It is not notarized.
