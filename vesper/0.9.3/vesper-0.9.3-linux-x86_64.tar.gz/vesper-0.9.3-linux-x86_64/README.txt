Vesper 0.9.3
Unpack this folder and run ./vesper.
This build is for 64-bit Linux (Pop!_OS and Ubuntu 24.04).
Qt and libVLC are in this folder. The codec plugins use the media libraries from that system.
The library is saved under ~/.local/share/vesper/vesper.
