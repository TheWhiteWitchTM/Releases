Vesper 0.9.3
Unzip this folder and run vesper.exe.
The library is saved in %APPDATA%\vesper\vesper.
