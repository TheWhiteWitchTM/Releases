MAGIC Dock 0.9.1
Unpack this folder and run ./magic-dock
To replace the COSMIC dock, run ./scripts/replace-cosmic-dock.sh from a terminal in the session.
