Ashen Crown 0.5.2
Unpack this folder and run ./ashencrown.
This build is for 64-bit Linux (Pop!_OS and Ubuntu 24.04).
Qt is in this folder. Sound uses the system's audio.
Buy me a coffee opens in your browser.
Settings are saved under ~/.config/AshenCrown.
