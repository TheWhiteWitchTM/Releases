Ashen Crown 0.5.2
Unzip this folder and run ashencrown.exe.
This build is for 64-bit Windows.
Buy me a coffee opens in your browser.
Settings are saved in %APPDATA%\AshenCrown.
