Ashen Crown 0.5.2
Open AshenCrown.app. The first time, Control-click it and choose Open.
If macOS says the app is damaged, run: xattr -dr com.apple.quarantine AshenCrown.app
This build is for Apple Silicon and needs macOS 14.4.
It is self-signed as TheWhiteWitchTM. It is not notarized.
Buy me a coffee opens in your browser.
Settings are saved in ~/Library/Preferences/AshenCrown.
