Blogy 0.8.2
Unzip this folder and run blogy.exe.
Settings are saved in %LOCALAPPDATA%\blogy.
Publish needs Git installed.
