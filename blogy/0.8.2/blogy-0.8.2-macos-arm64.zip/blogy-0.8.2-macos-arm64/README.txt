Blogy 0.8.2
Open blogy.app. The first time, Control-click it and choose Open.
If macOS says the app is damaged, run: xattr -dr com.apple.quarantine blogy.app
Settings are saved in ~/Library/Preferences/blogy.
Publish needs Git installed.
This build is for Apple Silicon and needs macOS 14.4. It is self-signed as TheWhiteWitchTM. It is not notarized.
