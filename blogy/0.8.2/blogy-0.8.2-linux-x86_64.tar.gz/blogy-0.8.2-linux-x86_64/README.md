# Blogy

A black Markdown editor for GitHub Pages blogs. Write a post, watch the preview, fix the front matter in a form, publish with git, tell Bluesky, and ask Grok for help. Built with Qt 6, in the same shape as Cinder and Vesper.

Blogy is generic: any Jekyll site (collections or `_posts`) or a Next.js MDX blog works once it is described in the config. The example config ships with three sites filled in (`whitewitch`, `mira`, `TheWhiteWitchTM.github.io`) that you can keep, edit, or delete.

## Open it

```bash
cd ~/Projects/blogy
scripts/build.sh
./blogy
```

`./blogy` runs `build/blogy` when this machine has Qt 6.12, and the bundled `dist/blogy` when it does not. Pass a post to open it:

```bash
./blogy ~/Projects/whitewitch/collections/_blog/2026-10-22-retro-center.md
./blogy --self-test
```

## Install (no sudo)

```bash
cd ~/Projects/blogy
./install.sh             # builds + bundles dist/ if missing, then installs
./install.sh --uninstall # removes it again
```

`install.sh` copies `dist/` to `~/.local/share/blogy`, writes a `~/.local/bin/blogy` launcher, installs `blogy.desktop` into `~/.local/share/applications` and the icon into `~/.local/share/icons/hicolor`. Blogy then shows up in the COSMIC app grid. If `~/.local/bin` is not on your PATH (Pop!_OS normally has it), the script says what to add to `~/.profile`. Uninstall keeps `~/.config/blogy`.

The same `install.sh` sits inside `dist/`, so a copied `dist/` folder installs on another machine without Qt.

## Build dependencies (Pop!_OS 22.04 / 24.04, Ubuntu)

```bash
sudo apt install build-essential qt6-base-dev qt6-base-dev-tools qt6-wayland \
    libgl1-mesa-dev git librsvg2-bin
# cmake, used by scripts/release.sh
```

No WebEngine: the preview uses Qt's built-in Markdown renderer. `librsvg2-bin` is only needed to re-export the icon PNGs from `resources/blogy.svg`.

`scripts/build.sh` uses `~/Qt/6.12.0/gcc_64/bin/qmake` when present, else `qmake6`, else `qmake`. With CMake instead:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
```

This is **0.8.2**. The version lives in `VERSION`, and `src/version.h` carries the same string. About and `--version` read it.

`scripts/release.sh` builds the Linux package. CMake does the compile. CPack writes `release/blogy-0.8.2-linux-x86_64.tar.gz`. Qt is taken from `QT_PREFIX`, or from `~/Qt/6.12.0/gcc_64`. `ghrelease` tags that version, pushes it, and copies the package into `~/Releases`.

## dist/

```bash
scripts/bundle-dist.sh
./dist/blogy
```

Same layout as Cinder: `dist/blogy` is the launcher, `dist/bin` the binary (+ `qt.conf`), `dist/lib` the Qt libraries it links, `dist/plugins` the platform (xcb, wayland, offscreen), image, icon, input, and TLS plugins (HTTPS for Grok and Bluesky), and `dist/share` the icons and desktop file. It runs on a machine that has no Qt installed.

## What it does

- Sites in the sidebar, posts grouped by collection, newest first.
- Markdown editor on a black page. It opens as the editor: Preview and Tools stay closed until you ask for them. The posts list on the left hides with the amber arrow at its top. That arrow stays on top of the list, and clicking it brings the list back. Escape, with a post open, asks to save, discard changes, or delete the file. Highlighting covers front matter, headings, emphasis, code, links, and Liquid tags. A fenced code block is colored for the language on its opening line. Lists continue on Enter. The top row is words, each button sized to its label: New Post, Open, Save, Upload image, Publish, Post to Bluesky, Preview, Tools, and Dictate. Preview fills the text area. Tools opens the side pane and stays lit while that pane is open. The pane has three tabs: AI, Front matter, and Publish. Settings is in the File menu. Help is in the Help menu. The format row under it is symbols: B, I, strike, lists, link, picture, an H menu (and a jump list of the headings in the post), and a code-block menu that inserts a fenced block tagged with the language. Hover a symbol for its name. Ctrl+B, Ctrl+I, Ctrl+K, Ctrl+` for bold, italic, link, code. Ctrl+1 through Ctrl+6 set the heading.
- Spelling and Tab completion, in the LibreSky shape. After two letters a list opens under the caret and the rest of the best word is shown in grey. Tab takes it. A lowercase word the dictionary does not know is underlined once you leave it. Right-click for another spelling, or add the word. Names and code are left alone.
- Dictate (Ctrl+Shift+D) is a toggle on the top row. Click to listen, click again to stop. It listens through the xAI speech API and writes Markdown: “heading two”, “bullet”, “bold … end bold”, “code block python”, “new paragraph”, “scratch that”, “finish the post”. “Finish the post” (also “write the post”) takes the outline in the editor, the site’s voice, and its Markdown style, and writes the full post. The prompt box can change that; leave it empty to write from what is already there. Dictate uses the signed-in Grok account, or the xAI key. The microphone audio goes to xAI only while Dictate is on.
- Find (Ctrl+F) and Replace (Ctrl+H). Help (F1) is the writing guide.
- Live preview (Ctrl+Shift+V) fills the text area, with the front matter shown as a header. Close it and the editor is back. Tools (Ctrl+J, and Ctrl+Shift+M) opens the side pane, and the same key closes it. The button stays lit on every tab. Front matter (Ctrl+M) opens that pane on the form. The Publish tab shows the repo, branch, file, and the git command.
- Front matter form built from the post's own keys: text, yes/no, and list fields; add or remove keys. Edits go straight into the file. MDX posts use `export const metadata = { ... }`.
- New Post (Ctrl+N): pick site and collection, type a title; the slug, file name (`2026-10-25-my-title.md`, or `my_title/page.mdx` for MDX), front matter, and future URL come from the site config.
- Save names the file from the title, using the collection's pattern. The date already in the file name stays. A collection that lives in `_posts` is GitHub Pages' default Jekyll engine, so the name is prefixed with the date (`2026-10-25-my-title.md`) even when the pattern forgot `{date}`.
- Publish (Ctrl+Shift+P): saves, then runs `git -C <repo> add -- <post>`, `git -C <repo> commit -m`, and `git -C <repo> push <remote> HEAD:<branch>` in the site's clone. The Publish tab shows that command, filled in from the site, before and while it runs. A rename is committed with the old path removed. Output is in the Publish tab, followed by the post URL. Your own git credentials (ssh agent, credential helper, `gh auth`) do the push; Blogy never handles a GitHub token. `GIT_TERMINAL_PROMPT=0` keeps git from hanging on a prompt.
- Settings is five tabs. Sites is the repo, the layout, and the tags. Markdown is the signature, the default heading, bold and italic, lists, and style notes. Publish appends the signature once. AI is Grok and the voice for the selected site. Bluesky is the handle and the app password. Editor is the font and link fixing.
- AI (inside Tools, Ctrl+J): a Grok chat that sees the post. Type in the prompt and press **Ask** (or Ctrl+Enter) for a free question. Finish the post, Polish, Front matter, Banner, Title + tags, and Bluesky blurb are the set jobs. Text already in the box is part of that job; leave the box empty and the job uses the draft alone. While a job is running the other buttons wait. Finish the post streams the file into the editor. A question stays in the chat; Apply to editor puts that reply in the post. The site's voice, Markdown style, layout, and tag list are sent with every request. Banner draws a 1200×630 card. The checkbox beside Polish does that too, when it is checked. Upload image, on the top row, uses a picture from this machine. It is not an AI job. Either one writes the file next to the post, under the post's name, and sets `image`, `image_width`, and `image_height` in the front matter, the same keys the sites use for the link card. The picture shows in the preview. The AI tab shows a small copy until you press Hide or Clear. An older card stays in the preview and does not fill the AI tab.
- After a publish: Post to Bluesky? The dialog is prefilled with the title and URL, counts graphemes against the 300 limit, and adds a link card. The card picture is the front-matter image when the post has one. Also under File → Post to Bluesky (Ctrl+Shift+B).

## Config

`~/.config/blogy/config.json`, written on first start from `config.example.json` with empty secrets, mode 0600. Window layout lives next to it in `blogy.conf`. Both stay out of every repo: Blogy refuses to write a config file inside a git work tree, and a `BLOGY_CONFIG` or `--config` path that points into one is ignored in favor of `~/.config/blogy/config.json`. `.gitignore` also excludes `config.json`, `blogy.conf`, `*.local.json` and `.env` in case one lands in the tree.

```json
{
  "editor":  { "fontSize": 13, "wrap": true, "previewDelayMs": 250 },
  "grok":    { "endpoint": "https://api.x.ai/v1/chat/completions", "model": "grok-4", "apiKey": "" },
  "bluesky": { "service": "https://bsky.social", "handle": "", "appPassword": "" },
  "sites": [
    {
      "name": "My blog",
      "type": "jekyll",
      "path": "~/Projects/my-blog",
      "branch": "main",
      "remote": "origin",
      "url": "https://username.github.io/my-blog",
      "slugSeparator": "-",
      "commitMessage": "Post: {title}",
      "signature": "— Your name\nhttps://username.github.io",
      "headingLevel": 2,
      "emphasis": "**",
      "listMarker": "-",
      "style": "short paragraphs, sentence-case headings",
      "collections": [
        { "name": "posts", "dir": "_posts", "file": "{date}-{slug}.md", "url": "/{year}/{month}/{day}/{slug}.html" }
      ],
      "layout": "post",
      "layouts": ["post", "default"],
      "tags": ["tech", "notes"],
      "frontMatter": { "layout": "post", "title": "", "date": "{date}", "description": "", "tags": [] },
      "template": "## {title}\n\n"
    }
  ]
}
```

- `type`: `jekyll` (YAML between `---`) or `mdx` (`export const metadata`).
- `url`: the public base URL including `baseurl`, e.g. `https://thewhitewitchtm.github.io/whitewitch`.
- `collections[].dir` is relative to the clone. For Jekyll collections with `collections_dir: collections` that is `collections/_blog`. `file` and `url` take `{date} {year} {month} {day} {slug} {category}` (`{category}` is the collection name). Jekyll's default collection URL is `/<collection>/<file name>.html`; `_posts` defaults to `/{year}/{month}/{day}/{slug}.html` without categories. Match your `permalink:` if you set one.
- `layout` is the Jekyll layout new posts use. `layouts` is every layout found in `_layouts` and in the posts, with the chosen one first. GitHub Pages looks up `_layouts/<layout>.html`. An MDX site leaves these out. A folder with no `_layouts` and no `layout:` in the posts uses `post`, which is what GitHub Pages' default theme expects. If the posts already share a layout, that one is stored instead of a guess.
- `tags` is the list the site already uses, most common first. New posts and Grok prefer it. It is not pasted onto every new post. The post's own tags still live in `frontMatter`.
- Point Settings → Read from folder at a blog and Blogy fills the layout, the tag list, the collections, and the front matter from the files. A Jekyll collection, `_posts`, or `blog/<name>/page.mdx` is enough.
- `collections[].frontMatter` adds keys for one collection (e.g. `video` for videos, `featured` for a collection that uses it).
- `signature`: Markdown appended to the post on publish. Set it under Settings → Markdown, one signature per site. Empty means nothing is added.
- `headingLevel` is the heading new sections use, from 1 to 6. The title stays in the front matter, so most posts use 2 (`##`). When the site template is only a heading line, new posts use this level. Leave it out and Blogy reads the level from that template (`##` is 2, `####` is 4). `emphasis` is `**` or `__`. `listMarker` is `-`, `*`, or `+`. `style` is any other note for Grok (paragraph length, spelling, what to leave out). Grok follows this on every request. `tune` is the voice, set on the AI tab.
- Sites can be edited in Settings (JSON, layout, and tags on Sites; signature and style on Markdown; voice on AI) or in the file.

### Secrets

| What | Config key | Environment (wins) |
| --- | --- | --- |
| xAI API key | `grok.apiKey` | `XAI_API_KEY` |
| Bluesky handle | `bluesky.handle` | `BLUESKY_HANDLE` |
| Bluesky app password | `bluesky.appPassword` | `BLUESKY_APP_PASSWORD` |

Use a Bluesky **app password** (Settings → Privacy and security → App passwords), never the account password. Secrets are only sent in request bodies or headers to the configured endpoints and are never logged or shown; the Settings fields are masked.

## How Bluesky posting works

1. `POST {service}/xrpc/com.atproto.server.createSession` with `identifier` + app password → `accessJwt`, `did`.
2. When the post has a front-matter image, `POST {service}/xrpc/com.atproto.repo.uploadBlob` with that JPEG. Then `POST {service}/xrpc/com.atproto.repo.createRecord` with `repo: did`, `collection: app.bsky.feed.post`, and a record holding the text, `createdAt`, link and hashtag facets (UTF-8 byte offsets), and an `app.bsky.embed.external` card (URL, title, description, and the blob as `thumb` when the upload worked).
3. The dialog shows the `bsky.app` link of the new post.

## How Grok works

With the Grok CLI signed in, Blogy runs that (`--prompt-file`, tools turned off, streaming text). A request to write the post streams into the editor. Other replies stay in the AI pane until you apply them. Otherwise `POST https://api.x.ai/v1/chat/completions` (OpenAI-compatible) with `Authorization: Bearer <key>`, the model from the config (`grok-4.7` by default; any model name xAI offers works), a system prompt, the conversation, and the post text for the quick jobs. The site tune is part of the system prompt.

## Layout

```
VERSION                      0.8.2, also in src/version.h
blogy.pro / CMakeLists.txt   qmake (used by scripts/build.sh) or CMake
scripts/release.sh           CMake release build, then CPack
src/main.cpp                 theme, command line, --self-test
src/config.*                 config.json, sites, secrets + env overrides
src/settings.*               window state (QSettings)
src/frontmatter.*            YAML / MDX metadata parse + write
src/post.*                   slugs, file names, URLs, new-post template
src/highlighter.* editor.*   Markdown highlighting and editing
src/preview.*                live preview
src/git.*                    git add / commit / push via QProcess
src/bluesky.*                AT Protocol client
src/grok.* grokauth.*       xAI chat client, and the signed-in Grok token used for dictation
src/ui/                      main window, front matter form, chat panel, dialogs
resources/                   blogy.qss (Cinder's black + ember theme), icon SVG/PNGs
scripts/build.sh             build into build/
scripts/bundle-dist.sh       build dist/ with Qt libs + plugins
install.sh                   per-user install / --uninstall
share/blogy.desktop          desktop entry
```

## Keys

Ctrl+N new post. Ctrl+O open. Ctrl+S save. Ctrl+Shift+P publish. Ctrl+Shift+B post to Bluesky. Ctrl+J Tools (Ctrl+Shift+M too). Ctrl+M front matter. Ctrl+Shift+D dictate. Ctrl+Shift+V preview. Ctrl+, settings. Ctrl+B / Ctrl+I / Ctrl+K / Ctrl+` bold, italic, link, code. Ctrl+Enter sends a chat message.

Blogy is MIT licensed. See `LICENSE`.
